from pathlib import Path
import json

import pandas as pd
import streamlit as st
from PIL import Image

from src.inference import (
    analyze_child_and_food,
    load_food_model,
    load_malnutrition_artifact,
)
from src.nutrition import (
    DISPLAY_NAMES,
    NUTRIENT_UNITS,
    build_nutrition_kb,
    build_recommendation_table,
)
from src.ui import (
    age_text,
    build_narrative,
    confidence_label,
    contribution_chart,
    contribution_dataframe,
    gap_chart,
    recommendation_chart,
)

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models"
DATA_DIR = BASE_DIR / "data"

st.set_page_config(
    page_title="NutriVision AI",
    page_icon="🥗",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
<style>
    .block-container {
        padding-top: 1.4rem;
        padding-bottom: 3rem;
        max-width: 1320px;
    }

    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #123A33 0%, #174C42 100%);
    }

    [data-testid="stSidebar"] * {
        color: #F7FFFC;
    }

    [data-testid="stSidebar"] input {
        color: #17332E !important;
    }

    .hero {
        padding: 28px 30px;
        border-radius: 24px;
        background: linear-gradient(120deg, #123A33 0%, #17745F 100%);
        color: white;
        margin-bottom: 20px;
    }

    .hero .eyebrow {
        opacity: .78;
        font-size: .85rem;
        letter-spacing: .08em;
        text-transform: uppercase;
        margin-bottom: 8px;
    }

    .hero h1 {
        margin: 0;
        font-size: 2.35rem;
        line-height: 1.1;
    }

    .hero p {
        margin: 10px 0 0;
        max-width: 780px;
        color: rgba(255,255,255,.83);
        font-size: 1rem;
    }

    .metric-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
        margin: 8px 0 22px;
    }

    .metric-box {
        padding: 18px;
        border-radius: 18px;
        background: white;
        border: 1px solid rgba(18,58,51,.10);
        box-shadow: 0 8px 28px rgba(18,58,51,.06);
    }

    .metric-label {
        color: #70817D;
        font-size: .82rem;
        margin-bottom: 7px;
    }

    .metric-value {
        color: #153B34;
        font-size: 1.35rem;
        font-weight: 750;
    }

    .metric-sub {
        color: #84938F;
        font-size: .78rem;
        margin-top: 5px;
    }

    .section-title {
        font-size: 1.18rem;
        font-weight: 720;
        color: #17332E;
        margin-top: 4px;
        margin-bottom: 3px;
    }

    .section-sub {
        color: #71817D;
        margin-bottom: 14px;
    }

    .insight {
        padding: 20px 22px;
        background: #EAF7F2;
        border: 1px solid #CAE8DD;
        border-radius: 18px;
        color: #183D35;
        line-height: 1.7;
    }

    .warning-note {
        padding: 15px 18px;
        background: #FFF8E8;
        border: 1px solid #F3E0AF;
        border-radius: 16px;
        color: #5F512B;
    }

    .food-rank {
        padding: 14px 16px;
        border-radius: 14px;
        background: #FFFFFF;
        border: 1px solid rgba(18,58,51,.10);
        margin-bottom: 10px;
    }

    .badge {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 999px;
        background: #E7F6F1;
        color: #12634F;
        font-size: .78rem;
        font-weight: 650;
    }

    @media (max-width: 900px) {
        .metric-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    }
</style>
""",
    unsafe_allow_html=True,
)


@st.cache_resource(show_spinner=False)
def load_models():
    food_path = MODEL_DIR / "food_classifier_best.keras"
    mal_path = MODEL_DIR / "malnutrition_model.joblib"

    missing = [p.name for p in [food_path, mal_path] if not p.exists()]
    if missing:
        raise FileNotFoundError(
            "Model belum tersedia: "
            + ", ".join(missing)
            + ". Export model dari notebook Colab dan letakkan di folder models/."
        )

    return load_food_model(food_path), load_malnutrition_artifact(mal_path)


@st.cache_data(show_spinner=False)
def load_data():
    required = {
        "class_names": MODEL_DIR / "class_names.json",
        "nutricheck": DATA_DIR / "nutricheck_nutrition.csv",
        "indonesia": DATA_DIR / "indonesia_nutrition.csv",
        "requirements": DATA_DIR / "nutrition_requirements.csv",
    }

    missing = [name for name, path in required.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Data deployment belum lengkap: "
            + ", ".join(missing)
            + ". Jalankan script export dari Colab terlebih dahulu."
        )

    class_names = json.loads(required["class_names"].read_text(encoding="utf-8"))
    nutricheck_df = pd.read_csv(required["nutricheck"])
    indonesia_df = pd.read_csv(required["indonesia"])
    requirements_df = pd.read_csv(required["requirements"])

    return class_names, nutricheck_df, indonesia_df, requirements_df


def metric_box(label, value, sub=""):
    st.markdown(
        f"""
        <div class="metric-box">
            <div class="metric-label">{label}</div>
            <div class="metric-value">{value}</div>
            <div class="metric-sub">{sub}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# -------------------------
# HERO
# -------------------------
st.markdown(
    """
<div class="hero">
    <div class="eyebrow">GEMASTIK • Multimodal Nutrition Intelligence</div>
    <h1>NutriVision AI</h1>
    <p>
        Screening pola status gizi anak, pengenalan citra makanan, analisis kontribusi
        nutrisi terhadap AKG, dan rekomendasi makanan Indonesia dalam satu dashboard.
    </p>
</div>
""",
    unsafe_allow_html=True,
)

# -------------------------
# SIDEBAR INPUT
# -------------------------
with st.sidebar:
    st.markdown("## 👶 Profil Anak")
    st.caption("Masukkan data antropometri untuk screening model.")

    age_months = st.number_input(
        "Umur (bulan)",
        min_value=6,
        max_value=83,
        value=36,
        step=1,
    )

    weight_kg = st.number_input(
        "Berat badan (kg)",
        min_value=3.0,
        max_value=40.0,
        value=11.0,
        step=0.1,
    )

    height_cm = st.number_input(
        "Tinggi badan (cm)",
        min_value=45.0,
        max_value=140.0,
        value=90.0,
        step=0.5,
    )

    muac_cm = st.number_input(
        "MUAC / LILA (cm)",
        min_value=5.0,
        max_value=30.0,
        value=12.0,
        step=0.1,
    )

    st.divider()
    st.caption(
        "Dashboard ini adalah prototipe edukasi dan screening, bukan diagnosis medis."
    )

# -------------------------
# UPLOAD AREA
# -------------------------
left, right = st.columns([1.05, 1], gap="large")

with left:
    st.markdown('<div class="section-title">📷 Upload Foto Makanan</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-sub">Gunakan foto makanan yang jelas dan fokus pada satu menu utama.</div>',
        unsafe_allow_html=True,
    )

    uploaded = st.file_uploader(
        "Pilih gambar",
        type=["jpg", "jpeg", "png", "webp"],
        label_visibility="collapsed",
    )

    if uploaded:
        image = Image.open(uploaded).convert("RGB")
        st.image(image, use_container_width=True, caption="Foto yang akan dianalisis")
    else:
        st.info("Upload foto makanan untuk mengaktifkan analisis.")

with right:
    st.markdown('<div class="section-title">🧾 Ringkasan Input</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-sub">Data ini digunakan sebagai konteks analisis sistem.</div>',
        unsafe_allow_html=True,
    )

    c1, c2 = st.columns(2)
    with c1:
        st.metric("Umur", age_text(age_months))
        st.metric("Berat", f"{weight_kg:g} kg")
    with c2:
        st.metric("Tinggi", f"{height_cm:g} cm")
        st.metric("MUAC/LILA", f"{muac_cm:g} cm")

    analyze = st.button(
        "✨ Analisis Sekarang",
        type="primary",
        use_container_width=True,
        disabled=uploaded is None,
    )

if not analyze:
    st.stop()

# -------------------------
# LOAD AND RUN
# -------------------------
try:
    with st.spinner("Memuat model dan menganalisis data..."):
        food_model, malnutrition_artifact = load_models()
        class_names, nutricheck_df, indonesia_df, requirements_df = load_data()

        nutricheck_kb, nutricheck_food_col, nutricheck_nutrient_cols = build_nutrition_kb(
            nutricheck_df
        )
        indo_kb, indo_food_col, indo_nutrient_cols = build_nutrition_kb(
            indonesia_df
        )
        indo_rec_df, indo_rec_cols = build_recommendation_table(
            indo_kb,
            indo_food_col,
            indo_nutrient_cols,
        )

        result = analyze_child_and_food(
            age_months=age_months,
            weight_kg=weight_kg,
            height_cm=height_cm,
            muac_cm=muac_cm,
            image=image,
            requirements=requirements_df,
            food_model=food_model,
            class_names=class_names,
            malnutrition_artifact=malnutrition_artifact,
            nutricheck_kb=nutricheck_kb,
            nutricheck_food_col=nutricheck_food_col,
            nutricheck_nutrient_cols=nutricheck_nutrient_cols,
            indo_rec_df=indo_rec_df,
            indo_food_col=indo_food_col,
            indo_rec_cols=indo_rec_cols,
        )
except Exception as exc:
    st.error("Dashboard belum dapat menjalankan inference.")
    st.code(str(exc))
    st.info(
        "Pastikan file hasil export Colab sudah diletakkan pada folder models/ dan data/ "
        "sesuai README."
    )
    st.stop()

# -------------------------
# RESULT CARDS
# -------------------------
status = result["nutrition_status"]
preds = result["food_prediction"]
top_food = preds[0]
certainty = confidence_label(preds)
bmi = status.get("bmi")

st.markdown("### Hasil Analisis")

st.markdown('<div class="metric-grid">', unsafe_allow_html=True)
metric_box(
    "Screening status gizi",
    str(status["prediction"]).title(),
    f"Confidence {status['confidence']*100:.1f}%" if status.get("confidence") else "Model tabular",
)
metric_box(
    "Makanan terdeteksi",
    str(top_food["food"]),
    f"Confidence {top_food['confidence']*100:.1f}%",
)
metric_box(
    "Kepastian citra",
    certainty,
    "Berdasarkan Top-1 dan margin Top-2",
)
metric_box(
    "BMI terhitung",
    f"{bmi:.2f}" if bmi is not None else "-",
    "Fitur model, bukan diagnosis",
)
st.markdown("</div>", unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(
    ["🥗 Analisis Nutrisi", "🍽️ Rekomendasi", "🧠 Detail Model"]
)

# -------------------------
# TAB NUTRITION
# -------------------------
with tab1:
    if result["food_nutrition"].get("status") != "ok":
        st.warning(result.get("warning", "Profil nutrisi makanan tidak ditemukan."))
    else:
        food_nutrients = result["food_nutrition"]["nutrients"]
        adequacy = result["nutrient_contribution"]

        st.markdown("#### Profil nutrisi makanan terdeteksi")
        nutrient_rows = []
        for key, value in food_nutrients.items():
            nutrient_rows.append(
                {
                    "Nutrisi": DISPLAY_NAMES.get(key, key),
                    "Jumlah": value,
                    "Satuan": NUTRIENT_UNITS.get(key, ""),
                }
            )
        st.dataframe(
            pd.DataFrame(nutrient_rows),
            use_container_width=True,
            hide_index=True,
        )

        st.caption(
            "Basis penyajian nutrisi mengikuti dataset NutriCheck. Validasi apakah per serving/per 100 g sebelum laporan final."
        )

        st.markdown("#### Kontribusi terhadap AKG kelompok umur")
        st.plotly_chart(
            contribution_chart(adequacy),
            use_container_width=True,
            config={"displayModeBar": False},
        )

        priority_df = contribution_dataframe(adequacy).sort_values("Gap", ascending=False)
        st.markdown("#### Prioritas untuk dilengkapi")
        st.dataframe(
            priority_df[["Nutrisi", "Kontribusi", "Gap", "Status"]].rename(
                columns={
                    "Kontribusi": "Kontribusi (%)",
                    "Gap": "Gap makanan (%)",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        st.plotly_chart(
            gap_chart(adequacy),
            use_container_width=True,
            config={"displayModeBar": False},
        )

# -------------------------
# TAB RECOMMENDATION
# -------------------------
with tab2:
    recommendations = result.get("recommendations", [])

    if not recommendations:
        st.info(
            "Belum ada kandidat rekomendasi yang dapat dihitung dari nutrien yang overlap dengan database."
        )
    else:
        st.markdown("#### Kandidat makanan Indonesia")
        st.caption(
            "Skor adalah ranking internal berdasarkan nutrient gap dan nutrien yang tersedia pada database, bukan skor kesehatan."
        )

        for idx, rec in enumerate(recommendations, start=1):
            st.markdown(
                f"""
                <div class="food-rank">
                    <span class="badge">#{idx} • {rec['score']:.0f}/100</span>
                    <div style="font-size:1.06rem;font-weight:700;margin-top:8px;color:#17332E;">
                        {rec['food']}
                    </div>
                    <div style="color:#70817D;margin-top:4px;">
                        {rec['reason']}
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        st.plotly_chart(
            recommendation_chart(recommendations),
            use_container_width=True,
            config={"displayModeBar": False},
        )

        st.markdown("#### Interpretasi untuk profil anak")
        st.markdown(
            f'<div class="insight">{build_narrative(result)}</div>',
            unsafe_allow_html=True,
        )

# -------------------------
# TAB MODEL
# -------------------------
with tab3:
    st.markdown("#### Top-3 prediksi citra")

    pred_table = pd.DataFrame(
        [
            {
                "Kelas": p["food"],
                "Confidence (%)": round(p["confidence"] * 100, 2),
            }
            for p in preds
        ]
    )
    st.dataframe(pred_table, use_container_width=True, hide_index=True)

    st.markdown("#### Pipeline")
    st.code(
        """Antropometri → model malnutrition → screening status gizi

Foto makanan → EfficientNetB0 → kelas makanan
             → NutriCheck nutrition mapping
             → dibandingkan dengan AKG umur
             → nutrient contribution / gap

Indonesian Food Nutrition
             → recommendation engine
             → ranking kandidat makanan"""
    )

    st.markdown(
        '<div class="warning-note">'
        '<b>Batasan:</b> satu foto tidak mewakili asupan 24 jam. '
        'AKG pada dashboard dipilih berdasarkan kelompok umur. '
        'Recommendation engine tidak memberikan terapi klinis.'
        '</div>',
        unsafe_allow_html=True,
    )